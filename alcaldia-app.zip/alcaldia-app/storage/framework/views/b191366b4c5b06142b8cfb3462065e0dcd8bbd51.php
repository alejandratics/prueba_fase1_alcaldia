<!-- resources/views/departamentos/index.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Departamentos</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('departamentos.create')); ?>"> Crear Nuevo Departamento</a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nombre</th>
            <th width="280px">Acción</th>
        </tr>
        <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($departamento->id); ?></td>
            <td><?php echo e($departamento->nombre); ?></td>
            <td>
                <form action="<?php echo e(route('departamentos.destroy', $departamento->id)); ?>" method="POST">
                    <a class="btn btn-info" href="<?php echo e(route('departamentos.show', $departamento->id)); ?>">Mostrar</a>
                    <a class="btn btn-primary" href="<?php echo e(route('departamentos.edit', $departamento->id)); ?>">Editar</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2024\htdocs\alcaldia-app\resources\views/departamentos/index.blade.php ENDPATH**/ ?>