<!-- resources/views/empleados/index.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Empleados</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('empleados.create')); ?>"> Crear Nuevo Empleado</a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Departamento</th>
            <th width="280px">Acción</th>
        </tr>
        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($empleado->id); ?></td>
            <td><?php echo e($empleado->nombre); ?></td>
            <td><?php echo e($empleado->email); ?></td>
            <td><?php echo e($empleado->telefono); ?></td>
            <td><?php echo e($empleado->departamento->nombre); ?></td>
            <td>
                <form action="<?php echo e(route('empleados.destroy', $empleado->id)); ?>" method="POST">
                    <a class="btn btn-info" href="<?php echo e(route('empleados.show', $empleado->id)); ?>">Mostrar</a>
                    <a class="btn btn-primary" href="<?php echo e(route('empleados.edit', $empleado->id)); ?>">Editar</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2024\htdocs\alcaldia-app\resources\views/empleados/index.blade.php ENDPATH**/ ?>