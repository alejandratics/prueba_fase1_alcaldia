<!DOCTYPE html>
<html>
<head>
    <title>Laravel CRUD</title>
    <!-- Agregar tus enlaces de CSS aquí -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="http://127.0.0.1:8000/">Alcaldía de Ibagué</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('departamentos.index')); ?>">Departamentos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('empleados.index')); ?>">Empleados</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Agregar tus scripts de JavaScript aquí -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html><?php /**PATH C:\xampp2024\htdocs\alcaldia-app\resources\views/welcome.blade.php ENDPATH**/ ?>